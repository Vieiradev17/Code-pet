// Seleciona o botão "Criar" pelo seletor de classe
const criarButton = document.querySelector('.create-button');

// Adiciona um evento de clique ao botão
criarButton.addEventListener('click', function() {
    // Ação a ser realizada quando o botão for clicado
    // Aqui você pode adicionar o código para a funcionalidade desejada
    console.log('Botão "Criar" foi clicado!');
    // Por exemplo, você pode adicionar aqui uma função para enviar os dados do formulário para um servidor ou realizar qualquer outra ação necessária
});
